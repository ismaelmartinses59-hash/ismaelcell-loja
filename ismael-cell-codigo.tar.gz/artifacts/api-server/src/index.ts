import app from "./app";
import { logger } from "./lib/logger";
import { db } from "@workspace/db";
import { sql } from "drizzle-orm";

async function ensureSchema(): Promise<void> {
  try {
    await db.execute(
      sql`ALTER TABLE pecas ADD COLUMN IF NOT EXISTS valor_custo text NOT NULL DEFAULT ''`,
    );
    await db.execute(sql`
      CREATE TABLE IF NOT EXISTS contas_receber (
        id serial PRIMARY KEY,
        nome text NOT NULL,
        tipo text NOT NULL DEFAULT 'cliente',
        created_at timestamp NOT NULL DEFAULT now(),
        closed_at timestamp
      )
    `);
    await db.execute(sql`
      CREATE TABLE IF NOT EXISTS contas_receber_itens (
        id serial PRIMARY KEY,
        conta_id integer NOT NULL,
        venda_id integer,
        modelo text NOT NULL,
        qualidade text NOT NULL,
        valor text NOT NULL,
        created_at timestamp NOT NULL DEFAULT now()
      )
    `);
    await db.execute(sql`
      CREATE TABLE IF NOT EXISTS contas_receber_pagamentos (
        id serial PRIMARY KEY,
        conta_id integer NOT NULL,
        valor text NOT NULL,
        created_at timestamp NOT NULL DEFAULT now()
      )
    `);
    logger.info("Schema check ok");
  } catch (err) {
    logger.error({ err }, "Schema check failed");
  }
}

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error(
    "PORT environment variable is required but was not provided.",
  );
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

ensureSchema().finally(() => {
  app.listen(port, (err) => {
    if (err) {
      logger.error({ err }, "Error listening on port");
      process.exit(1);
    }

    logger.info({ port }, "Server listening");
  });
});
